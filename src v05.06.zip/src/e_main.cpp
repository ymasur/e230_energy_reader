/* 	e_main.cpp
	----------
	YM: 20.12.2020
*/
#ifndef MAIN
#define MAIN

#include <Arduino.h>
#include "e230.h"
#include "e230_05.hpp"
#include "e_menu.h"

// -----------------------------------------------------------------------------

// Schedulers instances
//jm_Scheduler pulse_X_ms;
//jm_Scheduler pulse_1_s;

/* blink(short n=1, short t=1)
   ---------------------------
   Blink n times, with impulse cycle t (1/10 sec)
   *** Used only in setup operations ***
   I/O used: LED13
   return: -
*/
/*
void blink(short n=1, short t=1)
{
  for (short i=0; i<n; i++)
  {
    digitalWrite(LED13, LOW);
    delay(50 * t);
    digitalWrite(LED13, HIGH);
    delay(50 * t);
  }
}
*/

// log the error message 
void log_err(const char * msg)
{
  err_act = true; // make the error flag active (removed by menu)
  log_msg(msg);
}

// log the message and take the last one for reference
void log_msg(const char * msg)
{
  strncpy(last_log, msg, sizeof(last_log)-1);   // copy the message
  display_at_ln(msg);
  // msg.toCharArray(err_msg, 20);
  log_msg_SD(msg);
  Serial.println(err_msg);
}

// display an info for a short time, and not memorized
void log_info(const char * msg)
{
  tempo_msg = 10;
  display_at_ln(msg);
  log_msg_SD(msg);
  Serial.println(msg);
}

void setup()
{
  pinMode(SW1, INPUT);
  pinMode(SW2, INPUT);
  pinMode(LED_J, OUTPUT);
  pinMode(LED_R, OUTPUT);  

	// init an array of button control
	sw[0] = new Sw(SW1, "[+]");
	sw[1] = new Sw(SW2, "[-]");

	// I2C
	Wire.begin();

	// LCD
	lcd = new jm_LCM2004A_I2C();  // Add. 0X27 standard
	lcd->begin();  lcd->clear_display();
	lcd->print(__PROG__ " " VERSION);  // on line 1 of 4
  display_full_ln("LCD init done...", 0); //delay(2000);

	// we use serial for log messages
	Serial.begin(9600);
	display_full_ln("Serial started...",1);

	// RTC, start
	display_info("Start RTC, read.... ",2); //delay(2000);

	if (! rtc.begin()) 
	{
		display_full_ln("Couldn't find RTC",2); delay(2000);
		//blink(30,1);  // pulse LED13 3.0 sec at 0.1 Hz 
	}

	// global vars initialized
	myTime = rtc.now(); // get the RTC time
	bootTime = myTime;  // record the bootTime
	timeSyncInit();
	timeSyncStart();
  	
	menu = 0; // clear menu setting

	// set stream_in hardware...
#if defined AltSoftSerial_h
	STREAM_IN.begin(300);
#else
	STREAM_IN.begin(300, SERIAL_7E1);
#endif


	// stabilize STREAM_IN and STREAM_OUT RX/TX lines after reset/power up...
	delay(1000);

                //012345678901234567890
// display_info("Start polling loops");
//	pulse_1_s.start(poll_loop_1_s, 1000L * 1000);
//	pulse_X_ms.start(poll_loop_X_ms, 1000L * B_SCAN_PERIOD);



  // Bridge startup
  Bridge.begin();
  display_full_ln("Bridge begin",0); //delay(1000);

  // Listen for incoming connection only from localhost
  // (no one from the external network could connect)
#if 0
	server.listenOnLocalhost();
	server.begin();
#endif

	e230.begin();	
  display_full_ln("e230 begin",1); //delay(1000);

	FileSystem.begin();
  display_full_ln("Filesys begin",2); //delay(1000);

//	log_msg(__PROG__ " " VERSION );
	err_act = false;  // no error  
	
	display_full_ln("Programme pret.", 3); delay(3000);

} // end setup()

/*  void serial_cmd()
    -----------------
    Get key onto serial
    Global var modified:
    - menu
    - ser_copy

    The menu number is modified as the hardware switch[+] or [-].
    Limits and display is managed by e_menu.cpp
    The ser_copy byte use 4 bits as flags to control witch line of display (0..3)
    should be copied onto serial.
*/
void serial_cmd()
{
  int c;
  c = Serial.read();
  if (c == -1)
    return;

  //Serial.println(c);
  menu_changed = true;

  switch(c)
  {
    case '+':
      menu++;
      ser_copy = LN_all;        
    break;

    case '-':
      menu--;
      ser_copy = LN_all;  
    break;

    case '0': // menu base - energie actuelle
      menu = 0;
      ser_copy = LN_all;      
    break;

    case '1': // condensé énergie cons - prod - U - I - P
      menu = 1;
      ser_copy = LN1+LN2+LN3;
    break;

    case '2': // U, I, P des 3 phases
      menu = 2;
      ser_copy = LN1+LN2;      
    break;

    case '3': // dernier enreg.
      menu = 3;
      ser_copy = LN1+LN2;        
    break;

    case '4': // dernier log
      ser_copy = LN1+LN2+LN3;      
      menu = 4;
    break;

    case '5': // dernier boot
      ser_copy = LN1+LN2+LN3;      
      menu = 4;
    break;

    case ' ':
      ser_copy = LN_all;
    break;

    case '?':
    default:
      ser_copy = 0;
      Serial.println(F("\ncmd: +, -, menu 1, 2, 3, 4, 5."));
    break;
  }
} // serial_cmd()

enum proc { wait, ask, rec, calc };
u8 pstate;

void poll_loop_1_s()
{
  myTime = rtc.now(); // take the actual time
  tm_to_ascii(&myTime, dateTimeStr);

  Serial.println(dateTimeStr);
/*
  if (IsSyncTime_03h00())
    timeSyncStart();

  timeSync();
*/

  display_menu(); // rest of display depends of the menu choice

  if (IsSyncTime_10_seconds() && pstate == wait)
  {
    Serial.println(" ***Start");
    //e230.begin();
    e230.start();
    pstate = ask;
  }
  else if(!e230.ready() && pstate == ask)
  {
    pstate = rec;
    Serial.println(" get values");
  }
  else if(e230.ready() == true && e230.errored() == false && pstate == rec)
  {
    Serial.println(" calc values");
    get_all_values(get_e230_buf());
    pstate = calc;
  }
  else if(pstate == calc)
  {
    Serial.println(" ***Wait");
    pstate = wait;
  }
  
  if (pstate)
    LED_ON(LED_J);
  else
    LED_OFF(LED_J);

  if (IsSyncTime_15_minutes()) // Q: is time to store datas?
  {
    data_time = myTime; // copy of the time
    
    store_datas(fname, data_time); // A: yes, do this
  }

  //digitalWrite(LED13, !digitalRead(LED13)); // life monitoring - blink LED13
}


/*  poll_loop_X_ms()
    ----------------
    Compute the state of switches
    Modified var: intern of object Sw.
    The polling time must be between 10..50 ms
    Return value: -
*/
void poll_loop_X_ms()
{
  // scan all switches
  for(short i = 0; i < SW_NB; i++)
  {
    sw[i]->scan();
  }
/*
  if (e230.ready())
    LED_ON(LED_J);
  else
    LED_OFF(LED_J);

  if (e230.errored())
    LED_ON(LED_R);
    else 
    LED_OFF(LED_R);
*/
    
  menu_select(); // follow user choice
  serial_cmd();
}

/* main loop of Arduino
*/
#define SHORT_CYCLE 20  // 20 ms
#define MAIN_CYCLE 1000  // 1 sec.

void loop()
{
  static unsigned long fastPreviusMs, mainPreviusMs;

  unsigned long currentMs = millis();
  if (currentMs - fastPreviusMs > SHORT_CYCLE)
  {
    fastPreviusMs = currentMs;
    poll_loop_X_ms();
  }

  if (currentMs - mainPreviusMs > MAIN_CYCLE)
  {
    mainPreviusMs = currentMs;
    poll_loop_1_s();
  }  

	e230.cycle();
	//jm_Scheduler::cycle();

	yield();
  
}// loop()

#endif // MAIN
