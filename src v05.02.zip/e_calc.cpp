/*
	e_calc.cpp
	----------
	YM 13.12.2020
*/

#include "e230.h"
#include "e_calc.hpp"

enum { ST_RUN = 0, ST_ERR, ST_DONE };

class S_V
{
public:
	const char* signature;	// signature of the data, as "1.8.2"
	char* sval;			// value associated, as "230"
	double val;				// value

	char* get_sval();
};	// sruct s_v


char * S_V::get_sval()
{
	static char svaln[16];
	char* s = NULL;
	char *d = svaln;

	if (sval == NULL)
	{
		svaln[0] = '\0';
	}
	else
	{ 
		s = sval; 	d = svaln;
		do {
			*d++ = *s++;
		} while (*s != ')' && *s != '*' && *s != ' ' && *s != '\0' && d != svaln + sizeof(svaln) );
	}
	*d = '\0';

	return svaln;
}

class Data
{
public:
	S_V e_consumed, e_producted;
	S_V u_ph1, u_ph2, u_ph3; double u;
	S_V i_ph1, i_ph2, i_ph3; double i;
	S_V p_ph1, p_ph2, p_ph3; double p;
	S_V f_ph1, f_ph2, f_ph3; char f[3];	// only sign is useful

	int state;

#define NB_S_V (14)	// 2 energy, 3 u, 3 i, 3 p, 3 pf = 14 elements
	S_V* values[NB_S_V] =
	{
		&e_consumed, &e_producted,
		&u_ph1, &u_ph2, &u_ph3,
		&i_ph1, &i_ph2, &i_ph3,
		&p_ph1, &p_ph2, &p_ph3,
		&f_ph1, &f_ph2, &f_ph3,
	};

	void set_signatures()
	{
		e_consumed.signature = "1.8.0";	e_producted.signature = "2.8.0";
		u_ph1.signature = "32.7.0";;  u_ph2.signature = "52.7.0";;  u_ph3.signature = "72.7.0";;
		i_ph1.signature = "31.7.0";;  i_ph2.signature = "51.7.0";;  i_ph3.signature = "71.7.0";;
		p_ph1.signature = "36.7.0";;  p_ph2.signature = "56.7.0";;  p_ph3.signature = "76.7.0";;
		f_ph1.signature = "33.7.0";;  f_ph2.signature = "53.7.0";;  f_ph3.signature = "73.7.0";
	}

	void set_sens()
	{
		i_ph1.val *= f[0]; i_ph2.val *= f[1]; i_ph3.val *= f[2];
		p_ph1.val *= f[0]; p_ph2.val *= f[1]; p_ph3.val *= f[2];
	};

	void avg_u() { u = (u_ph1.val + u_ph2.val + u_ph3.val) / 3.0; }
	void avg_i() { i = (i_ph1.val + i_ph2.val + i_ph3.val) / 3.0; }
	void avg_p() { p = (p_ph1.val + p_ph2.val + p_ph3.val) / 3.0; }

	void avg()
	{
		avg_u(); avg_i(); avg_p();
	}


#define S_V_ATOF(DATA_NAME) (DATA_NAME.val = atof(DATA_NAME.sval))

	int conv()
	{
		e_consumed.val = atof(e_consumed.sval);
		e_producted.val = atof(e_producted.sval);

		S_V_ATOF(u_ph1);
		S_V_ATOF(u_ph2);
		S_V_ATOF(u_ph3);

		S_V_ATOF(i_ph1);
		S_V_ATOF(i_ph2);
		S_V_ATOF(i_ph3);

		S_V_ATOF(p_ph1);
		S_V_ATOF(p_ph2);
		S_V_ATOF(p_ph3);

		f[0] = *(f_ph1.sval) == '-' ? -1 : 1;
		f[1] = *(f_ph2.sval) == '-' ? -1 : 1;
		f[2] = *(f_ph3.sval) == '-' ? -1 : 1;

		set_sens();
		avg();		// compute average of 3 phases

		return OK;
	} // conv()


	// scan buffer and sets the pointers
	int populate(char* p_buf)
	{
		char* pscan = p_buf;	// point at start of buffer
		int i;
		int miss = 0;

		set_signatures();
		state = ST_RUN;

		for (i = 0; (i < NB_S_V) && (pscan < p_buf+E230_BUF_SZ) && (miss < 4);)
		{
			S_V* v = values[i];	// point struct value to found
			v->sval = NULL;	// clear value
			v->val = 0.0;	// clear value

			// printf("pscan: %s - signature: %10s\n", pscan, v->signature);
			//Serial.print("signature:"); Serial.println(v->signature);
			if (strncmp(pscan, v->signature, strlen(v->signature)) == 0)	// q: element found by signature?
			{
				// printf("*** signature trouvee: %s *** - ", v->signature);
				pscan = pscan + strlen(v->signature) + 1;	// go ahead the '('
				// printf(" valeur: %10s \n", pscan);
				v->sval = pscan;					// set sval to the next field
				pscan = pscan + strlen(pscan) + 1;	// go ahead the \0

				i++;		// next element to find
				miss = 0;	// reset miss counter
			}
			else
			{
				// printf("champ suivant (%d - %20s)\n",i, pscan);
				pscan = pscan + strlen(pscan) + 1;	// skip the field
				if (*pscan == '\0') miss++;

				// printf("miss: %d - p ascii: %s\n", miss,  pscan);
				//Serial.print("miss: "); Serial.println(pscan);
			}

		}

		// check if all signatures are found
		if (i == NB_S_V) state = ST_DONE; else state = ST_ERR;
		// printf("Elements found: %d of %d\n", i, NB_S_V);
		// Serial.print("Elements found:"); Serial.println(i);

		return state;
	}// populate()


	void print()
	{
		stream_out->println((char*)"[start]");
		
		if (state == ST_ERR)
		{
			stream_out->print("Error\n");
		}
		else if (state == ST_RUN)
		{
			stream_out->print("Run\n");
		}
		else
		{
			char buf[20];

			stream_out->print("E consommee: ");
			stream_out->println(e_consumed.get_sval());
			stream_out->print("E produite:  ");
			stream_out->println(e_producted.get_sval());

			stream_out->print("U ph1: "); stream_out->println(u_ph1.get_sval());
			stream_out->print("U ph2: "); stream_out->println(u_ph2.get_sval());
			stream_out->print("U ph3: "); stream_out->println(u_ph3.get_sval());

			stream_out->print("I ph1: "); stream_out->println(i_ph1.get_sval());
			stream_out->print("I ph2: "); stream_out->println(i_ph2.get_sval());
			stream_out->print("I ph3: "); stream_out->println(i_ph3.get_sval());

			stream_out->print("P ph1: "); stream_out->println(p_ph1.get_sval());
			stream_out->print("P ph2: "); stream_out->println(p_ph2.get_sval());
			stream_out->print("P ph3: "); stream_out->println(p_ph3.get_sval());

			stream_out->print("sens 1: "); stream_out->println(f_ph1.get_sval());
			stream_out->print("sens 2: "); stream_out->println(f_ph2.get_sval());
			stream_out->print("sens 3: "); stream_out->println(f_ph3.get_sval());

			//sprintf(buf, "%3.0f", u);
			dtostrf(u, 3, 0, buf);
			stream_out->print("U : "); stream_out->println(buf);
			//sprintf(buf, "%1.2f", i);
			dtostrf(i, 1, 2, buf);
			stream_out->print("I : "); stream_out->println(buf);
			//sprintf(buf, "%2.2f", p);
			dtostrf(p, 2, 2, buf);
			stream_out->print("P : "); stream_out->println(buf);

			stream_out->println("[end]");
		}

	} // print()

};	// class Data

Data data;

void get_all_values(char* p_buf)
{
	data.populate(p_buf);
	data.conv();
}

void data_print()
{
	data.print();
}
