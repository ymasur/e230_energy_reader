/* 	e_main.cpp
	----------
	YM: 26.11.2020 - adapted from e230_4.ino, from JM Paratte
*/
#define MAIN
#include "Arduino.h"
#include "e230.h"
#include "e230_05.hpp"
#include "e_calc.hpp"


// -----------------------------------------------------------------------------


jm_LCM2004A_I2C lcd;

void lcd_print20( const char * str )
{
	char buf[20+1];
	snprintf(buf, (20+1), "%-20s", str);
	lcd.set_cursor( 0, lcd_row );
	lcd.print(buf);
}

int nb_sessions;

void setup()
{
#if WITH_LCD
	Wire.begin();

	lcd.begin();
	lcd.clear_display();
	lcd_row = 0;
	delay(1000);

	lcd_print20(__PROG__);
#endif

Serial.begin(115200);
while(!Serial && millis()<3000) delay(1);

	// set stream_in hardware...
#if defined AltSoftSerial_h
	STREAM_IN.begin(300);
#else
	STREAM_IN.begin(300, SERIAL_7E1);
#endif
//	while (!STREAM_IN && millis()<3000) delay(1);

#if DEBUG
#if STREAM_OUT_ALSO_DEBUG
#else
	STREAM_DEBUG.begin(115200);
	while (!STREAM_DEBUG && millis()<3000) delay(1);
#endif
#endif

	// stabilize STREAM_IN and STREAM_OUT RX/TX lines after reset/power up...
	delay(1000);

	// Bridge startup
	Bridge.begin();

	// Listen for incoming connection only from localhost
	// (no one from the external network could connect)
	server.listenOnLocalhost();
	server.begin();

	e230.begin();

//	e230.start();
}

void loop()
{
	e230.cycle();

	if (e230.started()) 
	{
	}
	else 
	{
		// Get clients coming from server
		BridgeClient client = server.accept();
	//	client = server.accept();

		// Is there a new client?
		if (client) 
		{
			// Process request
			String s = client.readString();

			client.print(F("\xEF\xBB\xBF")); //BOM UTF-8 https://en.wikipedia.org/wiki/Byte_order_mark

			if (s == String("start" STR_CRLF)) 
			{
				//
				if (e230.start())
				{
					client.println(_OK_);
					nb_sessions++;
				}
					
				else
					client.println(_ER_);
			}
			else if (s == String("print" STR_CRLF)) 
			{
				//
				stream_out = & client;
				e230.stream_out_excel();
				stream_out = & Serial;
			}
			else if (s == String("buf" STR_CRLF)) 
			{
				//
				stream_out = & client;
				e230.stream_out_buf();
				stream_out = & Serial;
			}
			else if (s == String("data" STR_CRLF)) 
			{
				//
				stream_out = & client;
				get_all_values(	get_e230_buf() );
				data_print();
				stream_out = & Serial;
			}
			else 
			{
				client.println(_ER_);
			}

			// Close connection and free resources.
			client.stop();
		} // client in work

	}	// e230 stopped

}
