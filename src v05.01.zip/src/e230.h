/*  e230.h
	------
	Definitions part
	YM: 26.11.2020 - adapted from e230_4.ino, from JM Paratte
*/

// #define WITH_LCD

#ifndef E230_H
#define E230_H

#ifndef _WIN32
#include <Arduino.h>
#include <Bridge.h>
#include <BridgeServer.h>
#include <BridgeClient.h>
#include <FileIO.h>
#include <avr/wdt.h>
#include <string.h>
#include <Wire.h>
#include <OneWire.h>
#include <time.h>
#include <RTClib.h>
#include <jm_Scheduler.h>
#include <jm_LCM2004A_I2C.h>
#else // 
#include <stdio.h>
#include <string>
#include <stdlib.h>     /* atof */
#endif // _WIN32

// Storage class of common variables, always in main module
#ifdef MAIN
  #define CLASS // intern...
#else
  #define CLASS extern
#endif
// -----------------------------------------------------------------------------

// https://www.arduino.cc/reference/en/language/functions/communication/serial/

// Arduino Yún
// -----------

// https://www.pjrc.com/teensy/td_libs_AltSoftSerial.html

// TX, RX, SWRX - D13, SWTX - D5

#ifndef _WIN32
#include <AltSoftSerial.h>
CLASS AltSoftSerial SwSerial;
#endif //

#define STREAM_OUT_IS_KEYBOARD (false)

#define STREAM_OUT_ALSO_DEBUG (true)

#define STREAM_IN SwSerial

#define STREAM_OUT Serial

#if STREAM_OUT_ALSO_DEBUG
#	define STREAM_DEBUG STREAM_OUT
#else
#	define STREAM_DEBUG
#endif

//#endif //

#define E230_BUF_SZ (540)
#define CHR_NUL	'\x00'
#define CHR_STX	'\x02'
#define CHR_ETX	'\x03'
#define CHR_ACK	'\x06'
#define CHR_TAB	'\t'	// '\x09'
#define CHR_LF	'\n'	// '\x0A'
#define CHR_CR	'\r'	// '\x0D'

#define STR_STX	"\x02"
#define STR_ETX	"\x03"
#define STR_ACK	"\x06"
#define STR_TAB	"\t"
#define STR_LF	"\n"
#define STR_CR	"\r"
#define STR_CRLF "\r\n"
// -----------------------------------------------------------------------------

#define OK true
#define ER false

#define _OK_ "=OK="
#define _ER_ "#ER#"

/*

// Arduino UNO
// -----------

// https://www.pjrc.com/teensy/td_libs_AltSoftSerial.html

//// TX, RX, SWRX - D10, SWTX - D11
//
//#include <SoftwareSerial.h>
//SoftwareSerial SwSerial(10, 11, false);

// TX, RX, SWRX - D8, SWTX - D9

#include <AltSoftSerial.h>
AltSoftSerial SwSerial;

#define STREAM_OUT_IS_KEYBOARD (false)

#define STREAM_OUT_ALSO_DEBUG (true)

#define STREAM_IN SwSerial

#define STREAM_OUT Serial

#if STREAM_OUT_ALSO_DEBUG
#	define STREAM_DEBUG STREAM_OUT
#else
#	define STREAM_DEBUG
#endif

*/


/*

// Leonardo
// --------

#define STREAM_OUT_IS_KEYBOARD (false)

#define STREAM_OUT_ALSO_DEBUG (true)

#define STREAM_IN Serial1

#if STREAM_OUT_IS_KEYBOARD
#	include <jm_Keyboard_Swiss.h>
#	define STREAM_OUT Keyboard
#else
#	define STREAM_OUT Serial
#endif

#if STREAM_OUT_ALSO_DEBUG
#	define STREAM_DEBUG STREAM_OUT
#else
#	define STREAM_DEBUG Serial
#endif

*/


/*

// DUE Programming Port
// --------------------

#define STREAM_OUT_IS_KEYBOARD (false)

#define STREAM_OUT_ALSO_DEBUG (true)

#define STREAM_IN Serial1

#if STREAM_OUT_IS_KEYBOARD
#	include <jm_Keyboard_Swiss.h>
#	define STREAM_OUT Keyboard
#else
#	define STREAM_OUT Serial
#endif

#if STREAM_OUT_ALSO_DEBUG
#	define STREAM_DEBUG STREAM_OUT
#else
#	define STREAM_DEBUG
#endif

*/


/*

// ESP32 DEVKIT
// ------------

// TX - 1, RX - 3, RX1 - 9, TX1 - 10, RX2 - 16, TX2 - 17, SDA - 21, SCL - 22

#define STREAM_OUT_IS_KEYBOARD (false)

#define STREAM_OUT_ALSO_DEBUG (true)

#define STREAM_IN Serial2 // pins 16 et 17

#define STREAM_OUT Serial

#if STREAM_OUT_ALSO_DEBUG
#	define STREAM_DEBUG STREAM_OUT
#else
#	define STREAM_DEBUG
#endif

*/


/*

// ESP8266 WeMos D1 mini
// ---------------------

// TX, RX, SWRX - D5, SWTX - D4, SDA - D2, SCL - D1

#include <SoftwareSerial.h>
SoftwareSerial SwSerial(D5, D4, false);

#define STREAM_OUT_IS_KEYBOARD (false)

#define STREAM_OUT_ALSO_DEBUG (true)

#define STREAM_IN SwSerial

#define STREAM_OUT Serial

#if STREAM_OUT_ALSO_DEBUG
#	define STREAM_DEBUG STREAM_OUT
#else
#	define STREAM_DEBUG
#endif

*/


// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------

// Common vars
CLASS int lcd_row;

#ifndef _WIN32
CLASS Stream * stream_in
#ifdef MAIN
 = & STREAM_IN;
 #else
 ;
 #endif

CLASS Stream * stream_out
#ifdef MAIN
 = & STREAM_OUT;
#else
;
#endif
// Listen to the default port 5555, the Yún webserver
// will forward there all the HTTP requests you send
CLASS BridgeServer server;
//BridgeClient client;

#endif // __Arduino

// Function definition (VS-CODE)

void lcd_print20( const char * str );
char * get_e230_buf();
void get_all_values(char * p_buf);
void print_data_values(char * p_buf);
void data_print();

#ifdef _WIN32
#include <stdio.h>

class Print_out
{
    public:
    Print_out(){};
	void print(const char * p){ printf(p); };
    void println(const char *p){ printf(p); printf("\n"); };
};

CLASS Print_out print_out;
CLASS Print_out * stream_out
#ifdef MAIN
 = &print_out;
#endif
 ;

#else
  #define sprintf_s sprintf // Visual Studio 2019 need this implementation
#endif // _WIN32

#endif // e230_h
